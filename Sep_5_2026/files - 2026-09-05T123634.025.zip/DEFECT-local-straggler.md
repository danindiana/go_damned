# Defect: the 2009 guard omits the local half of the CMB discipline

**Severity:** exactness violation. The guard the repository presents as correct,
and that TLC reports as satisfying `Exactness`, commits spikes that the
sequential oracle does not produce.

**Status:** minimal counterexample below, four neurons. Fix implemented as
guard `2009L`. Verified 0 failures where `2009` fails up to 57%.

---

## 1. Statement

`tryComputeAndEmit` gates the start of a computation on peer bounds only:

```go
top := pl.cm.minStamp()
ok := true
if e.cfg.Guard == "2009" {
    for _, b := range pl.clk {      // pl.clk holds PEER bounds
        if !(top < b) { ok = false; break }
    }
}
```

`pl.clk` is indexed by peer. It does not describe this processor. So the gate
proves that no *remote* processor can still deliver an impact at or before
`top`, and proves nothing about work this processor is itself holding.

But this processor may hold, at that instant:

- a `CPEvent` in `pl.cp`: a neuron already known to fire at stamp `s`, whose
  emission is authorized separately and has not yet happened; or
- a `CMEvent` in `pl.running`: an impact inside an EC goroutine which may yet
  cross threshold and produce a spike at stamp `s`.

Either becomes an impact on a local target at `s + d`, `d >= dmin`. If
`top >= s + dmin` and that impact is inhibitory, the sequential oracle applies
it *before* the event at `top` — inhibition sorts first at equal stamps — and
the target does not fire. The distributed engine integrates the excitation
first and commits a spike that has no counterpart in ground truth.

The emission guard does check `localClear`, but that is the wrong place and the
wrong quantity: it runs at commit time on events already in `pl.cm`, and by then
the premature computation has happened.

## 2. Why the existing scenarios cannot expose it

| scenario | inhibitory source | its target | exposes? |
|---|---|---|---|
| `cancel` | N3 on proc 2 | N0 on proc 1 | no — remote |
| `ring`   | N0 on proc 1 | N3 on proc 1 | no — no competing remote excitation at the same stamp |

Both place the inhibition where the *peer-bound* half of the guard covers it.
The hole is on the complementary path: inhibition **local** to its target,
excitation **remote**. No test in the repository has that shape.

This is worth stating plainly because it is a coverage failure, not bad luck.
The two scenarios were built to exercise the 2006 bug, and they do that well.
They were not built to search the space of source-placement configurations, so
the second configuration was never tried.

## 3. Minimal counterexample — `scenario=fanin-local`

Four neurons, the mirror image of `cancel`:

```
N0  theta=2   proc 1     target
N1  theta=1   proc 2     excitatory, REMOTE, w=+2 d=2  -> impacts N0 at t=2
N2  theta=1   proc P     excitatory, REMOTE, w=+2 d=2  -> impacts N0 at t=2
N3  theta=1   proc 1     inhibitory, LOCAL,  w=-4 d=1  -> impacts N0 at t=2
stim: N1@0, N2@0, N3@1
```

Ground truth: `[[0 1] [0 2] [1 3]]`. N0 never fires — at t=2 the -4 sorts first,
so the potential path is 0 -> -4 -> -2 -> 0.

Observed, 600 runs, latency 0:

| P | guard 2006 | guard 2009 | guard 2009L |
|---|---|---|---|
| 2 | 23/600 | **17/600** | 0/600 |
| 3 | 47/600 | 0/600 | 0/600 |
| 4 | 116/600 | **6/600** | 0/600 |

`flagged-unsound` is **0** in every 2009 failure. See section 5.

## 4. Fix

Add the local half of the same bound computation. A local forecast or in-flight
computation at stamp `s` can produce impacts no earlier than `s + dmin`, so no
event at or after that may be integrated yet:

```go
if ok && e.cfg.Guard == "2009L" {
    selfB := INF
    for _, c := range pl.cp      { if c.St < selfB { selfB = c.St } }
    for _, r := range pl.running { if r.St < selfB { selfB = r.St } }
    if selfB < INF && !(top < selfB+e.dmin) { ok = false }
}
```

`pl.cm` is deliberately excluded: its minimum *is* `top`, and including it would
self-block. The two collections that matter are the ones `myBound` already
consults but the computation gate does not.

**No deadlock.** Emission of the blocking CP event `c` requires
`localClear(c.Ni, c.St)`, which may require computing a local event at stamp
`<= c.St = selfB < selfB + dmin`. Such an event is still authorized, so the
blocking event always drains.

**No regression.** `cancel` and `ring` are 0/300 under both `2009` and `2009L`.

## 5. Second defect: the soundness oracle does not detect this class

`flagged-unsound` was **0** in every single 2009 failure recorded here — 0/600
on `fanin-local`, 0/100 on every cell of the word-problem sweep — while the
spike-train comparison against `sequentialEDS` caught all of them. On `fanin`
with the 2006 guard the oracle reports 0/300 against 275/300 actual mismatches.

`PendingWouldCancel` is therefore a considerably weaker instrument than the
README and the proofs diagrams present it as. Anything relying on it as *the*
correctness detector — rather than on oracle comparison — is under-testing.
Recommend demoting it in the documentation to a diagnostic hint and promoting
spike-train equality to the stated criterion.

## 6. Third defect (unrelated, found first): inFlight accounting leak

`processorLoop` decrements `inFlight` once per **message**; the send side
increments once per **event**. Every message with fan-out > 1 leaks
`len(Evs)-1`, quiescence is never detected, and the engine hangs. Invisible in
`cancel`/`ring` because per-peer fan-out is 1 in both. Fix is one line, included
in the patch.

## 7. Consequences for the TLA+ model

`DamnedFull2.tla` should be checked for the same asymmetry. If its computation
action is likewise gated only on `kb[m]` for peers `m`, then `Exactness` holding
at `FIX=TRUE` reflects the specification sharing the implementation's blind spot
rather than the discipline being sound. Two things to establish:

1. Does the model permit a state where a processor holds an un-emitted local
   spike while integrating a same-processor impact at a later stamp? If the
   model serializes local work implicitly, the configuration is unreachable and
   the counterexample above is an artifact of the Go implementation's EC
   goroutines rather than of the algorithm.
2. If it is reachable, add a `fanin-local`-shaped initial condition. Config A
   (`P=2, MaxT=2, DMax=2`) is large enough — the counterexample needs `P=2` and
   stamps up to 2.

Until (1) is answered, the claim that model checking *proves* the 2009 fix
correct should be scoped to: TLC found no violation of `Exactness` in the
reachable states of this model at these constants.

## 8. Note for the on-chip port

Message latency **masks** this defect rather than amplifying it — the opposite
of the 2006 bug's behaviour. Under 1ms simulated latency the 2009 guard passes
`fanin-local` 300/300; at zero latency it fails. The race is local inhibition
against remote excitation, so delaying remote traffic lets the local path win.

The adversarial regime is therefore tight coupling and low latency, which is
precisely the on-chip NoC case rather than the MPI-cluster case the papers
targeted. A port to a mesh interconnect moves toward the failing end of this
axis, not away from it.
