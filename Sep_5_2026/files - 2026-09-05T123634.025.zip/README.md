# damned-witness

Additions to `danindiana/go_damned` turning it into a Tier 1 substrate witness,
plus three defects found in the process.

| file | what |
|---|---|
| `WITNESS_REPORT.md` | the witness: construction, results, what it discharges |
| `DEFECT-local-straggler.md` | the 2009 guard is not sound; 4-neuron counterexample; fix |
| `witness_group.go` | new — group algebra, network builder, witness driver |
| `fanin.go` | new — two minimal counterexample scenarios |
| `Damned.patch` | 59 lines against Damned.go: inFlight fix, guard `2009L`, scenario wiring |

Apply with `git apply Damned.patch`, drop the two `.go` files in the repo root,
then `go build -o damned Damned.go witness_group.go fanin.go`.

## Headline

- `S5` word problem tracked on **364 neurons / 1080 synapses, constant in n**,
  depth `2n`. `NC1`-complete capability from temporal state, not spatial width.
- The published **2009 guard returns the wrong group element in 44% of runs at
  n=32**. Reduced to four neurons (`scenario=fanin-local`).
- The repo's own soundness flag reports **0 violations in every one of those
  failures**. Only oracle comparison catches them.
- `inFlight` accounting leaks on any multi-event message, hanging the engine on
  dense networks. One-line fix.
- Corrected guard `2009L`: 0 failures across the whole sweep, no regression on
  `cancel` or `ring`.
